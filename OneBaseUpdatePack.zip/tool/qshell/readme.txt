﻿// 七牛静态资源同步脚本使用

1.将 qshell 目录中的文件 复制到 静态资源目录 public 中

2.填写 qupload.txt 文件中的配置信息

3.以管理员身份运行 cmd， cd 到 public 目录

4.执行 command.txt 中的命令