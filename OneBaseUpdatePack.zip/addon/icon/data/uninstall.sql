DELETE FROM ob_hook WHERE `name` = 'Icon';

DELETE FROM ob_addon WHERE `name` = 'Icon';