INSERT INTO `ob_hook` (`name`, `describe`, `addon_list`, `status`, `update_time`, `create_time`) VALUES ('ArticleEditor', '富文本编辑器', 'Editor', '1', '0', '0');

INSERT INTO `ob_addon` (`name`, `title`, `describe`, `config`,  `author`, `version`, `status`, `create_time` , `update_time`)  VALUES ('Editor', '文本编辑器', '富文本编辑器', '', 'Bigotry', '1.0', '1', '0', '0');