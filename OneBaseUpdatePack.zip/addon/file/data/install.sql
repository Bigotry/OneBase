INSERT INTO `ob_hook` (`name`, `describe`, `addon_list`, `status`, `update_time`, `create_time`) VALUES ('File', '文件上传钩子', 'File', '1', '0', '0');

INSERT INTO `ob_addon` (`name`, `title`, `describe`, `config`,  `author`, `version`, `status`, `create_time` , `update_time`)  VALUES ('File', '文件上传', '文件上传插件', '', 'Jack', '1.0', '1', '0', '0');