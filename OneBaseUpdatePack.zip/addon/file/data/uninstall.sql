DELETE FROM ln_hook WHERE `name` = 'File';

DELETE FROM ln_addon WHERE `name` = 'File';