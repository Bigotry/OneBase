
-- -----------------------------
-- Table structure for `ob_addon`
-- -----------------------------
DROP TABLE IF EXISTS `ob_addon`;
CREATE TABLE `ob_addon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名称',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '插件描述',
  `config` text NOT NULL COMMENT '配置',
  `author` varchar(40) NOT NULL DEFAULT '' COMMENT '作者',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '版本号',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `ob_addon`
-- -----------------------------
INSERT INTO `ob_addon` VALUES ('22', 'Editor', '文本编辑器', '富文本编辑器', '', 'Bigotry', '1.0', '1', '0', '0');
INSERT INTO `ob_addon` VALUES ('29', 'File', '文件上传', '文件上传插件', '', 'Bigotry', '1.0', '1', '0', '0');
INSERT INTO `ob_addon` VALUES ('30', 'Imgs', '多图上传', '多图上传插件', '', 'Bigotry', '1.0', '1', '0', '0');

-- -----------------------------
-- Table structure for `ob_api`
-- -----------------------------
DROP TABLE IF EXISTS `ob_api`;
CREATE TABLE `ob_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(150) NOT NULL DEFAULT '' COMMENT '接口名称',
  `group_id` int(6) unsigned NOT NULL DEFAULT '0' COMMENT '接口分组',
  `request_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '请求类型 0:POST  1:GET',
  `api_url` char(50) NOT NULL DEFAULT '' COMMENT '请求路径',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '接口描述',
  `describe_text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '接口富文本描述',
  `is_request_data` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要请求数据',
  `request_data` text NOT NULL COMMENT '请求数据',
  `response_data` text NOT NULL COMMENT '响应数据',
  `is_response_data` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要响应数据',
  `is_user_token` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要用户token',
  `is_data_sign` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否返回数据签名',
  `response_examples` text NOT NULL COMMENT '响应栗子',
  `developer` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '研发者',
  `api_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '接口状态（0:待研发，1:研发中，2:测试中，3:已完成）',
  `is_page` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为分页接口 0：否  1：是',
  `sort` tinyint(5) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=192 DEFAULT CHARSET=utf8 COMMENT='API表';

-- -----------------------------
-- Records of `ob_api`
-- -----------------------------
INSERT INTO `ob_api` VALUES ('186', '登录或注册', '34', '0', 'common/login', '系统登录注册接口，若用户名存在则验证密码正确性，若用户名不存在则注册新用户，返回 user_token 用于操作需验证身份的接口', '', '1', '[{\"field_name\":\"username\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u7528\\u6237\\u540d\"},{\"field_name\":\"password\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u5bc6\\u7801\"}]', '[{\"field_name\":\"data\",\"data_type\":\"2\",\"field_describe\":\"\\u4f1a\\u5458\\u6570\\u636e\\u53causer_token\"}]', '1', '0', '1', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;member_id&quot;: 51,\r\n        &quot;nickname&quot;: &quot;sadasdas&quot;,\r\n        &quot;username&quot;: &quot;sadasdas&quot;,\r\n        &quot;create_time&quot;: &quot;2017-09-09 13:40:17&quot;,\r\n        &quot;user_token&quot;: &quot;eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJPbmVCYXNlIEpXVCIsImlhdCI6MTUwNDkzNTYxNywiZXhwIjoxNTA0OTM2NjE3LCJhdWQiOiJPbmVCYXNlIiwic3ViIjoiT25lQmFzZSIsImRhdGEiOnsibWVtYmVyX2lkIjo1MSwibmlja25hbWUiOiJzYWRhc2RhcyIsInVzZXJuYW1lIjoic2FkYXNkYXMiLCJjcmVhdGVfdGltZSI6IjIwMTctMDktMDkgMTM6NDA6MTcifX0.6PEShODuifNsa-x1TumLoEaR2TCXpUEYgjpD3Mz3GRM&quot;\r\n    }\r\n}', '0', '1', '0', '0', '1', '1504501410', '1504949075');
INSERT INTO `ob_api` VALUES ('187', '文章分类列表', '44', '0', 'article/categorylist', '文章分类列表接口', '', '0', '', '[{\"field_name\":\"id\",\"data_type\":\"0\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\"},{\"field_name\":\"name\",\"data_type\":\"0\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7b\\u540d\\u79f0\"}]', '1', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: [\r\n        {\r\n            &quot;id&quot;: 2,\r\n            &quot;name&quot;: &quot;测试文章分类2&quot;\r\n        },\r\n        {\r\n            &quot;id&quot;: 1,\r\n            &quot;name&quot;: &quot;测试文章分类1&quot;\r\n        }\r\n    ]\r\n}', '0', '0', '0', '0', '1', '1504765581', '1504769645');
INSERT INTO `ob_api` VALUES ('188', '文章列表', '44', '0', 'article/articlelist', '文章列表接口', '', '1', '[{\"field_name\":\"category_id\",\"data_type\":\"0\",\"is_require\":\"0\",\"field_describe\":\"\\u82e5\\u4e0d\\u4f20\\u9012\\u6b64\\u53c2\\u6570\\u5219\\u4e3a\\u6240\\u6709\\u5206\\u7c7b\"}]', '', '0', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;total&quot;: 9,\r\n        &quot;per_page&quot;: &quot;10&quot;,\r\n        &quot;current_page&quot;: 1,\r\n        &quot;last_page&quot;: 1,\r\n        &quot;data&quot;: [\r\n            {\r\n                &quot;id&quot;: 16,\r\n                &quot;name&quot;: &quot;11111111&quot;,\r\n                &quot;category_id&quot;: 2,\r\n                &quot;describe&quot;: &quot;22222222&quot;,\r\n                &quot;create_time&quot;: &quot;2017-08-07 13:58:37&quot;\r\n            },\r\n            {\r\n                &quot;id&quot;: 15,\r\n                &quot;name&quot;: &quot;tttttt&quot;,\r\n                &quot;category_id&quot;: 1,\r\n                &quot;describe&quot;: &quot;sddd&quot;,\r\n                &quot;create_time&quot;: &quot;2017-08-07 13:24:46&quot;\r\n            }\r\n        ]\r\n    }\r\n}', '0', '0', '1', '0', '1', '1504779780', '1504780445');
INSERT INTO `ob_api` VALUES ('189', '首页接口', '45', '0', 'combination/index', '首页聚合接口', '', '1', '[{\"field_name\":\"category_id\",\"data_type\":\"0\",\"is_require\":\"0\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\"}]', '[{\"field_name\":\"article_category_list\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7b\\u6570\\u636e\"},{\"field_name\":\"article_list\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u6570\\u636e\"}]', '1', '0', '1', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;article_category_list&quot;: [\r\n            {\r\n                &quot;id&quot;: 2,\r\n                &quot;name&quot;: &quot;测试文章分类2&quot;\r\n            },\r\n            {\r\n                &quot;id&quot;: 1,\r\n                &quot;name&quot;: &quot;测试文章分类1&quot;\r\n            }\r\n        ],\r\n        &quot;article_list&quot;: {\r\n            &quot;total&quot;: 8,\r\n            &quot;per_page&quot;: &quot;2&quot;,\r\n            &quot;current_page&quot;: &quot;1&quot;,\r\n            &quot;last_page&quot;: 4,\r\n            &quot;data&quot;: [\r\n                {\r\n                    &quot;id&quot;: 15,\r\n                    &quot;name&quot;: &quot;tttttt&quot;,\r\n                    &quot;category_id&quot;: 1,\r\n                    &quot;describe&quot;: &quot;sddd&quot;,\r\n                    &quot;create_time&quot;: &quot;2017-08-07 13:24:46&quot;\r\n                },\r\n                {\r\n                    &quot;id&quot;: 14,\r\n                    &quot;name&quot;: &quot;1111111111111111111&quot;,\r\n                    &quot;category_id&quot;: 1,\r\n                    &quot;describe&quot;: &quot;123123&quot;,\r\n                    &quot;create_time&quot;: &quot;2017-08-04 15:37:20&quot;\r\n                }\r\n            ]\r\n        }\r\n    }\r\n}', '0', '0', '1', '0', '1', '1504785072', '1504948716');
INSERT INTO `ob_api` VALUES ('190', '详情页接口', '45', '0', 'combination/details', '详情页接口', '', '1', '[{\"field_name\":\"article_id\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u6587\\u7ae0ID\"}]', '[{\"field_name\":\"article_category_list\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7b\\u6570\\u636e\"},{\"field_name\":\"article_details\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u8be6\\u60c5\\u6570\\u636e\"}]', '1', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;article_category_list&quot;: [\r\n            {\r\n                &quot;id&quot;: 2,\r\n                &quot;name&quot;: &quot;测试文章分类2&quot;\r\n            },\r\n            {\r\n                &quot;id&quot;: 1,\r\n                &quot;name&quot;: &quot;测试文章分类1&quot;\r\n            }\r\n        ],\r\n        &quot;article_details&quot;: {\r\n            &quot;id&quot;: 1,\r\n            &quot;name&quot;: &quot;213&quot;,\r\n            &quot;category_id&quot;: 1,\r\n            &quot;describe&quot;: &quot;test001&quot;,\r\n            &quot;content&quot;: &quot;第三方发送到&quot;&quot;&quot;,\r\n            &quot;create_time&quot;: &quot;2014-07-22 11:56:53&quot;\r\n        }\r\n    }\r\n}', '0', '0', '0', '0', '1', '1504922092', '1504923179');
INSERT INTO `ob_api` VALUES ('191', '修改密码', '34', '0', 'common/changepassword', '修改密码接口', '', '1', '[{\"field_name\":\"old_password\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u65e7\\u5bc6\\u7801\"},{\"field_name\":\"new_password\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u65b0\\u5bc6\\u7801\"}]', '', '0', '1', '0', 'dfdd', '0', '0', '0', '0', '1', '1504941496', '1504941496');

-- -----------------------------
-- Table structure for `ob_api_group`
-- -----------------------------
DROP TABLE IF EXISTS `ob_api_group`;
CREATE TABLE `ob_api_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(120) NOT NULL DEFAULT '' COMMENT 'aip分组名称',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COMMENT='api分组表';

-- -----------------------------
-- Records of `ob_api_group`
-- -----------------------------
INSERT INTO `ob_api_group` VALUES ('34', '基础接口', '0', '1504501195', '0', '1');
INSERT INTO `ob_api_group` VALUES ('44', '文章接口', '1', '1504765319', '1504765319', '1');
INSERT INTO `ob_api_group` VALUES ('45', '聚合接口', '0', '1504784149', '1504784149', '1');

-- -----------------------------
-- Table structure for `ob_article`
-- -----------------------------
DROP TABLE IF EXISTS `ob_article`;
CREATE TABLE `ob_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '文章名称',
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文章分类',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `content` text NOT NULL COMMENT '文章内容',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面图片id',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件id',
  `img_ids` varchar(200) NOT NULL DEFAULT '',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文章表';

-- -----------------------------
-- Records of `ob_article`
-- -----------------------------
INSERT INTO `ob_article` VALUES ('1', '1', '213', '1', 'test001', '第三方发送到<img src=\"/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg\" alt=\"\" />', '58', '0', '', '1406001413', '1492886147', '-1');
INSERT INTO `ob_article` VALUES ('2', '20', 'ASDSA', '1', 'ASDAS', '第三方发送到<img src=\"/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg\" alt=\"\" />', '72', '0', '', '1492882194', '1493390183', '-1');
INSERT INTO `ob_article` VALUES ('3', '20', '测试文章001', '1', '测试文章001', '第三方发送到<img src=\"/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg\" alt=\"\" />', '62', '0', '', '1492886092', '1493437552', '-1');
INSERT INTO `ob_article` VALUES ('4', '20', '我的文章', '1', '121', '第三方发送到<img src=\"/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg\" alt=\"\" />', '0', '0', '', '1493171565', '1493380326', '-1');
INSERT INTO `ob_article` VALUES ('5', '20', '12121212', '2', '12121212123234343', '第三方发送到<img src=\"/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg\" alt=\"\" />', '0', '0', '', '1493366781', '1493380332', '-1');
INSERT INTO `ob_article` VALUES ('6', '20', 'ghshah11', '1', 'gsbs', '第三方发送到&lt;img src=&quot;http://ougehzmlx.bkt.clouddn.com/upload/picture/20170812/8da59419241df6e53a3f0d0e51363931.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;http://ougehzmlx.bkt.clouddn.com/upload/picture/20170812/4bf45d0d563a58eee79e6d361463c861.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg&quot; alt=&quot;&quot; /&gt;', '138', '0', '', '1493386505', '1502516939', '1');
INSERT INTO `ob_article` VALUES ('7', '20', '343', '1', '343', '第三方发送到&lt;img src=&quot;/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg&quot; alt=&quot;&quot; /&gt;', '136', '0', '', '1494399408', '1502511429', '1');
INSERT INTO `ob_article` VALUES ('8', '20', '沿江1', '1', '沿江1沿江1沿江1沿江1沿江1沿江1', '第三方发送到<img src=\"/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg\" alt=\"\" />', '90', '0', '', '1495096214', '1495096214', '1');
INSERT INTO `ob_article` VALUES ('9', '20', '321', '1', '2132131313123', '第三方发送到1&lt;img src=&quot;/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg&quot; alt=&quot;&quot; /&gt;', '0', '0', '', '1495267523', '1501068531', '1');
INSERT INTO `ob_article` VALUES ('10', '20', '12', '1', '12', '第三方发送到<img src=\"/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg\" alt=\"\" />', '0', '0', '', '1495421183', '1495421190', '-1');
INSERT INTO `ob_article` VALUES ('11', '20', 'w1w1w1', '1', '&amp;quot;&amp;lt;script&amp;gt;ript&amp;gt;&amp;quot;', '第三方发送到<img src=\"/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg\" alt=\"\" />', '0', '0', '', '1495443753', '1495443753', '1');
INSERT INTO `ob_article` VALUES ('12', '20', 'w1w1', '1', '&amp;amp;amp;amp;amp;amp;quot;&amp;amp;amp;amp;amp;amp;lt;script&amp;amp;amp;amp;amp;amp;gt;ript&amp;amp;amp;amp;amp;amp;gt;&amp;amp;amp;amp;amp;amp;quot;', '第三方发送到&lt;img src=&quot;/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg&quot; alt=&quot;&quot; /&gt;', '113', '0', '', '1495443770', '1502076940', '-1');
INSERT INTO `ob_article` VALUES ('13', '20', '我我', '1', '&amp;quot;&amp;lt;script&amp;gt;ript&amp;gt;&amp;quot;', '第三方发送到<img src=\"/public/upload/editor/20170423/38725073c5fc1064fee682e52db9c9b7.jpg\" alt=\"\" />', '0', '0', '', '1495443840', '1495443840', '1');
INSERT INTO `ob_article` VALUES ('14', '1', '1111111111111111111', '1', '123123', '&lt;span style=&quot;color:#E53333;&quot;&gt;1&lt;/span&gt;&lt;strong&gt;&lt;span style=&quot;color:#E53333;&quot;&gt;23&lt;/span&gt;1&lt;span style=&quot;background-color:#E56600;&quot;&gt;231大跌&lt;img src=&quot;/upload/editor/20170804/dd42b00099f4a1005e80a47901c10078.jpg&quot; alt=&quot;&quot; /&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp; &lt;img src=&quot;https://www.baidu.com/img/bd_logo1.png&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;\r\n&lt;/span&gt;&lt;/strong&gt;', '119', '0', '', '1501832240', '1502081568', '1');
INSERT INTO `ob_article` VALUES ('15', '1', 'tttttt', '1', 'sddd', 'sdf', '130', '0', '', '1502083486', '1502085552', '1');
INSERT INTO `ob_article` VALUES ('16', '1', '11111111', '2', '22222222', '3333333333', '128', '0', '', '1502085517', '1502085517', '1');
INSERT INTO `ob_article` VALUES ('17', '1', '213', '1', '12312', '3435435', '0', '0', '', '1504850204', '1504850204', '1');
INSERT INTO `ob_article` VALUES ('18', '1', '435345', '1', '54645', 'fghfhg', '0', '0', '', '1504850223', '1504850223', '1');
INSERT INTO `ob_article` VALUES ('19', '1', '测试文章解析', '1', '测试文章解析', '&lt;p&gt;\r\n	测试文章&lt;span style=&quot;color:#E53333;&quot;&gt;解析的萨达萨达&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;span style=&quot;color:#E53333;&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;span style=&quot;color:#E53333;&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;span style=&quot;color:#E53333;&quot;&gt;&amp;nbsp;&lt;img src=&quot;/upload/picture/20170909/3ebca0d68dcbaef128c197be4c2bd719.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;', '169', '13', '170', '1504925600', '1506306647', '1');
INSERT INTO `ob_article` VALUES ('20', '1', '测试文章TIANJ', '2', '滴滴滴滴', '对对对', '170', '12', '169,170', '1506306762', '1506306762', '1');

-- -----------------------------
-- Table structure for `ob_article_category`
-- -----------------------------
DROP TABLE IF EXISTS `ob_article_category`;
CREATE TABLE `ob_article_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `icon` char(20) NOT NULL DEFAULT '' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类表';

-- -----------------------------
-- Records of `ob_article_category`
-- -----------------------------
INSERT INTO `ob_article_category` VALUES ('1', '测试文章分类1', '分类1描述222', '1379474947', '1495085174', '1', 'fa-cny');
INSERT INTO `ob_article_category` VALUES ('2', '测试文章分类2', '33223', '1379475028', '1493363830', '1', 'fa-credit-card');
INSERT INTO `ob_article_category` VALUES ('4', 'admin', '222', '1493718987', '1501755167', '-1', '');
INSERT INTO `ob_article_category` VALUES ('5', '1212', '121221', '1495379896', '1501755164', '-1', '1111');
INSERT INTO `ob_article_category` VALUES ('6', 'w1w1', 'w1w1', '1495443641', '1501755160', '-1', '');

-- -----------------------------
-- Table structure for `ob_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `ob_auth_group`;
CREATE TABLE `ob_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '用户组名称',
  `describe` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(1000) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='权限组表';

-- -----------------------------
-- Records of `ob_auth_group`
-- -----------------------------
INSERT INTO `ob_auth_group` VALUES ('1', 'admin', '默认用户组', '', '1', '1,16,17,108,109,27,68,70,126,75,124,135,136,140,141,142,143,144,145,146', '1', '1501068879', '0');
INSERT INTO `ob_auth_group` VALUES ('2', '', '223333', '23232', '-1', '', '1', '1492272441', '1492270480');
INSERT INTO `ob_auth_group` VALUES ('3', '', 'test001', 'test001', '1', '', '1', '1492442806', '1492442806');
INSERT INTO `ob_auth_group` VALUES ('4', '', '测试组', '测试组', '1', '', '1', '1493264950', '1493264950');
INSERT INTO `ob_auth_group` VALUES ('5', '', '123333', '', '1', '', '1', '1493342725', '1493342725');
INSERT INTO `ob_auth_group` VALUES ('6', '', 'test', '11111111', '1', '', '1', '1493718907', '1493718907');
INSERT INTO `ob_auth_group` VALUES ('7', '', '测试权限组001', '测试权限组001', '1', '1,16,17,108,109,134,18,27,32,34,35,36,128,68,69,70,71,72,73,126,75,98,124,125,127,135,136,140,141,142,143,151,152,144,145,150,153,146,147,154,148,149', '1', '1502246405', '1502165257');
INSERT INTO `ob_auth_group` VALUES ('8', '', 'T1权限组', 'T1权限组', '1', '1,16,17,108,109,134,18,27,32,34,35,36,128,135,136,144,145,150,153,146,147,154,148,149', '38', '1502246562', '1502246484');
INSERT INTO `ob_auth_group` VALUES ('9', '', 'T6权限组', 'T6权限组', '1', '', '43', '1502246648', '1502246648');

-- -----------------------------
-- Table structure for `ob_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `ob_auth_group_access`;
CREATE TABLE `ob_auth_group_access` (
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户组id',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户组授权表';

-- -----------------------------
-- Records of `ob_auth_group_access`
-- -----------------------------
INSERT INTO `ob_auth_group_access` VALUES ('18', '1', '1492233212', '1492233212', '1');
INSERT INTO `ob_auth_group_access` VALUES ('20', '1', '0', '0', '1');
INSERT INTO `ob_auth_group_access` VALUES ('39', '7', '1502172347', '1502172347', '1');
INSERT INTO `ob_auth_group_access` VALUES ('40', '7', '1502173936', '1502173936', '1');
INSERT INTO `ob_auth_group_access` VALUES ('41', '7', '1502174065', '1502174065', '1');
INSERT INTO `ob_auth_group_access` VALUES ('38', '7', '1502246448', '1502246448', '1');
INSERT INTO `ob_auth_group_access` VALUES ('43', '8', '1502246604', '1502246604', '1');

-- -----------------------------
-- Table structure for `ob_config`
-- -----------------------------
DROP TABLE IF EXISTS `ob_config`;
CREATE TABLE `ob_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置标题',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置选项',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COMMENT='配置表';

-- -----------------------------
-- Records of `ob_config`
-- -----------------------------
INSERT INTO `ob_config` VALUES ('1', 'seo_title', '1', '网站标题', '1', '', '网站标题前台显示标题，优先级低于SEO模块', '1378898976', '1506161399', '1', 'ssssssss11', '3');
INSERT INTO `ob_config` VALUES ('2', 'seo_description', '2', '网站描述', '1', '', '网站搜索引擎描述，优先级低于SEO模块', '1378898976', '1506161399', '1', '', '100');
INSERT INTO `ob_config` VALUES ('3', 'seo_keywords', '2', '网站关键字', '1', '', '网站搜索引擎关键字，优先级低于SEO模块', '1378898976', '1506161399', '1', 'test11', '99');
INSERT INTO `ob_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1492273146', '-1', '1', '1');
INSERT INTO `ob_config` VALUES ('9', 'config_type_list', '3', '配置类型列表', '3', '', '主要用于数据解析和页面表单的生成', '1378898976', '1506310525', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '100');
INSERT INTO `ob_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1492276833', '-1', 'asdas', '9');
INSERT INTO `ob_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1492273182', '-1', 'blue_color', '10');
INSERT INTO `ob_config` VALUES ('20', 'config_group_list', '3', '配置分组', '3', '', '配置分组', '1379228036', '1506310525', '1', '1:基础\r\n2:数据\r\n3:系统\r\n4:API', '100');
INSERT INTO `ob_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1492272816', '-1', '1:视图\r\n2:控制器', '100');
INSERT INTO `ob_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1492272794', '-1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '100');
INSERT INTO `ob_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1492272799', '-1', '1', '1');
INSERT INTO `ob_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '1', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1492272804', '-1', '60', '2');
INSERT INTO `ob_config` VALUES ('25', 'list_rows', '0', '每页数据记录数', '2', '', '数据每页显示记录数', '1379503896', '1502532557', '1', '10', '10');
INSERT INTO `ob_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1492272822', '-1', '1', '3');
INSERT INTO `ob_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1492272835', '-1', 'erlang-dark', '3');
INSERT INTO `ob_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1492273011', '-1', './Data/', '5');
INSERT INTO `ob_config` VALUES ('29', 'data_backup_part_size', '0', '数据库备份卷大小', '2', '', '该值用于限制压缩后的分卷最大长度。单位：B', '1381482488', '1505556357', '1', '52428800', '7');
INSERT INTO `ob_config` VALUES ('30', 'data_backup_compress', '4', '数据库备份文件是否启用压缩', '2', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1505544001', '1', '1', '9');
INSERT INTO `ob_config` VALUES ('31', 'data_backup_compress_level', '4', '数据库备份文件压缩级别', '2', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1505544076', '1', '9', '10');
INSERT INTO `ob_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1492272922', '-1', '1', '11');
INSERT INTO `ob_config` VALUES ('33', 'allow_url', '3', '不受权限验证的url', '3', '', '', '1386644047', '1506310525', '1', '0:file/pictureupload\r\n1:addon/execute', '100');
INSERT INTO `ob_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '1', '', '仅超级管理员可访问的控制器方法', '1386644141', '1492272998', '-1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '100');
INSERT INTO `ob_config` VALUES ('35', 'REPLY_LIST_ROWS', '1', '回复列表每页条数', '2', '', '', '1386645376', '1492273230', '-1', '10', '0');
INSERT INTO `ob_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '3', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1492276749', '-1', '', '12');
INSERT INTO `ob_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '3', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1492275918', '-1', '0', '1');
INSERT INTO `ob_config` VALUES ('42', 'system_title', '1', '系统标题', '1', '', '', '1492276942', '1492277685', '-1', '', '0');
INSERT INTO `ob_config` VALUES ('43', 'empty_list_describe', '1', '数据列表为空时的描述信息', '2', '', '', '1492278127', '1502532557', '1', 'aOh! 暂时还没有数据~', '0');
INSERT INTO `ob_config` VALUES ('44', 'trash_config', '3', '回收站配置', '3', '', 'key为模型名称，值为显示列。', '1492312698', '1506310525', '1', 'Config:name\r\nAuthGroup:name\r\nMember:nickname\r\nMenu:name\r\nArticle:name\r\nArticleCategory:name\r\nAddon:name\r\nPicture:name', '0');
INSERT INTO `ob_config` VALUES ('46', 'fasdf', '0', 'ddddddddddddd', '0', '', '', '1493958784', '1493958784', '1', '', '0');
INSERT INTO `ob_config` VALUES ('47', 'wp', '0', '我的wp', '0', '', '', '1494082221', '1494082221', '1', '', '0');
INSERT INTO `ob_config` VALUES ('48', 'is_auto_cache', '4', '是否开启自动缓存', '1', '0:否\r\n1:是', '自动缓存开启后 getInfo 与 getList 方法获取的数据会自动缓存', '1494222635', '1506161399', '1', '1', '0');
INSERT INTO `ob_config` VALUES ('49', 'static_domain', '1', '静态资源域名', '1', '', '若静态资源为本地资源则此项为空，若为外部资源则为存放静态资源的域名', '1502430387', '1506161399', '1', '', '0');
INSERT INTO `ob_config` VALUES ('50', 'cache_max_number', '0', '系统最大缓存数量', '2', '', '', '1502526883', '1502532557', '1', '2000', '0');
INSERT INTO `ob_config` VALUES ('51', 'cache_clear_interval_time', '0', '缓存自动回收时间', '2', '', '', '1502526950', '1502532557', '1', '1000', '0');
INSERT INTO `ob_config` VALUES ('52', 'team_developer', '3', '研发团队人员', '4', '', '', '1504236453', '1506749181', '1', '0:Bigotry\r\n1:扫地僧', '0');
INSERT INTO `ob_config` VALUES ('53', 'api_status_option', '3', 'API接口状态', '4', '', '', '1504242433', '1506749181', '1', '0:待研发\r\n1:研发中\r\n2:测试中\r\n3:已完成', '0');
INSERT INTO `ob_config` VALUES ('54', 'api_data_type_option', '3', 'API数据类型', '4', '', '', '1504328208', '1506749181', '1', '0:字符\r\n1:文本\r\n2:数组\r\n3:文件', '0');
INSERT INTO `ob_config` VALUES ('55', 'frontend_theme', '1', '前端主题', '1', '', '', '1504762360', '1506161399', '1', 'default', '0');
INSERT INTO `ob_config` VALUES ('56', 'api_domain', '1', 'API部署域名', '4', '', '', '1504779094', '1506749181', '1', 'http://www.onebase.org', '0');
INSERT INTO `ob_config` VALUES ('57', 'api_key', '1', 'API加密KEY', '4', '', '泄露后API将存在安全隐患', '1505302112', '1506749181', '1', 'l2V|gfZp{8`;jzR~6Y1_', '0');
INSERT INTO `ob_config` VALUES ('58', 'loading_icon', '4', '页面Loading图标设置', '1', '1:图标1\r\n2:图标2\r\n3:图标3\r\n4:图标4\r\n5:图标5\r\n6:图标6\r\n7:图标7', '页面Loading图标支持7种图标切换', '1505377202', '1506161399', '1', '7', '101');
INSERT INTO `ob_config` VALUES ('59', 'sys_file_field', '3', '文件字段配置', '3', '', 'key为模型名，值为文件列名。', '1505799386', '1506315470', '1', 'article:file_id', '0');
INSERT INTO `ob_config` VALUES ('60', 'sys_picture_field', '3', '图片字段配置', '3', '', 'key为模型名，值为图片列名。', '1506315422', '1506315456', '1', 'article:cover_id\r\narticle:img_ids', '0');
INSERT INTO `ob_config` VALUES ('61', 'jwt_key', '1', 'JWT加密KEY', '4', '', '', '1506748805', '1506749181', '1', 'l2V|DSFXXXgfZp{8`;FjzR~6Y1_', '0');

-- -----------------------------
-- Table structure for `ob_driver`
-- -----------------------------
DROP TABLE IF EXISTS `ob_driver`;
CREATE TABLE `ob_driver` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `service_name` varchar(40) NOT NULL DEFAULT '' COMMENT '服务标识',
  `driver_name` varchar(20) NOT NULL DEFAULT '' COMMENT '驱动标识',
  `config` text NOT NULL COMMENT '配置',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='插件表';


-- -----------------------------
-- Table structure for `ob_file`
-- -----------------------------
DROP TABLE IF EXISTS `ob_file`;
CREATE TABLE `ob_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '保存名称',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '远程地址',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文件表';

-- -----------------------------
-- Records of `ob_file`
-- -----------------------------
INSERT INTO `ob_file` VALUES ('12', '0ede17e1b9f87f4b089b363a7baba8ae.docx', '20170923/0ede17e1b9f87f4b089b363a7baba8ae.docx', 'upload/file/20170923/0ede17e1b9f87f4b089b363a7baba8ae.docx', '85aadaaefef63212aacc18eff7ab65b3701913f3', '1506160624', '1506160624', '1');
INSERT INTO `ob_file` VALUES ('13', 'b76d1ad478bc39017563bd3056cfda8a.png', '20170923/b76d1ad478bc39017563bd3056cfda8a.png', 'upload/file/20170923/b76d1ad478bc39017563bd3056cfda8a.png', '106149c6f44037465a3f44c212eac5a1ae6cf7da', '1506160952', '1506160952', '1');

-- -----------------------------
-- Table structure for `ob_hook`
-- -----------------------------
DROP TABLE IF EXISTS `ob_hook`;
CREATE TABLE `ob_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `describe` varchar(255) NOT NULL COMMENT '描述',
  `addon_list` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COMMENT='钩子表';

-- -----------------------------
-- Records of `ob_hook`
-- -----------------------------
INSERT INTO `ob_hook` VALUES ('23', 'ArticleEditor', '富文本编辑器', 'Editor', '1', '0', '0');
INSERT INTO `ob_hook` VALUES ('30', 'File', '文件上传钩子', 'File', '1', '0', '0');
INSERT INTO `ob_hook` VALUES ('31', 'Imgs', '多图上传钩子', 'Imgs', '1', '0', '0');

-- -----------------------------
-- Table structure for `ob_member`
-- -----------------------------
DROP TABLE IF EXISTS `ob_member`;
CREATE TABLE `ob_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `username` char(16) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` char(32) NOT NULL DEFAULT '' COMMENT '密码',
  `email` char(32) NOT NULL DEFAULT '' COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户状态',
  `leader_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '上级会员ID',
  `is_share_member` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否共享会员',
  `is_inside` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为后台使用者',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `ob_member`
-- -----------------------------
INSERT INTO `ob_member` VALUES ('1', 'admin', 'admin', 'e47a151f635f88a40b9df97bcaa1230b', '3162875@qq.com', '18521353333', '1506749942', '0', '1', '0', '0', '1');
INSERT INTO `ob_member` VALUES ('19', 'test001', 'test001', '3596686391f9edec50313d508fb69030', '3162875a@qq.com', '', '1492272403', '0', '-1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('20', 'demo', 'demo', '3596686391f9edec50313d508fb69030', 'demo@qq.com', '', '1504946862', '1492395155', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('21', 'qqqqqqq', 'qqqqqqq', '3596686391f9edec50313d508fb69030', '11112211@qq.com', '', '1492396857', '1492396857', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('22', 'test01', 'test01', '70b3401ed7941d7e3600d08f45aa93b7', 'test@test.test', '', '1492397258', '1492397258', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('23', '324234324324', '324234324324', '70b3401ed7941d7e3600d08f45aa93b7', '43243@q.comk', '', '1492402062', '1492402062', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('24', 'testlogin', 'testlogin', '6bf5bcf9a6d56202a7ac04da18c4554b', 'test@admin.com', '', '1492418310', '1492418310', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('25', 'bbbb', 'bbbb', '70b3401ed7941d7e3600d08f45aa93b7', 'cccc@qq.cn', '', '1492422889', '1492422889', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('26', 'test999', 'test999', '3596686391f9edec50313d508fb69030', '878787@qq.com', '', '1492442622', '1492442622', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('27', 'dsad', 'dsad', '70b3401ed7941d7e3600d08f45aa93b7', 'sadsa@qq.com', '', '1492754798', '1492754798', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('28', 'kkk', 'kkk', '70b3401ed7941d7e3600d08f45aa93b7', 'ddd@qq.com', '', '1501143075', '1492917871', '-1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('29', 'tony', 'tony', '70b3401ed7941d7e3600d08f45aa93b7', '548794787@qq.com', '', '1493111973', '1493111761', '-1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('30', 'ererer', 'ererer', '3596686391f9edec50313d508fb69030', '123123@asd.com', '', '1501904643', '1493342691', '-1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('31', '233', '233', '716bb7469ee90adb36811c58f397508f', '233@23.com', '', '1494142866', '1494142866', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('32', 'aaaaa', 'aaaaa', '3596686391f9edec50313d508fb69030', 'aaaa@163.com', '', '1494395106', '1494395106', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('33', 'fsadfsdafsadf', 'fsadfsdafsadf', '70b3401ed7941d7e3600d08f45aa93b7', 'fsaf@fasdf.dwf', '', '1494571422', '1494571422', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('34', 'bw', 'bw', '70b3401ed7941d7e3600d08f45aa93b7', '1111@qq.com', '', '1495096259', '1495096259', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('35', 'bw123', 'bw123', '3570313aa5965a58348cb0ba6fdfa8d8', 'bw@123.com', '', '1495096313', '1495096313', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('36', '111111', '111111', '3596686391f9edec50313d508fb69030', '1111222211@qq.com', '', '1495444202', '1495444202', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('37', '111111111', '111111111', '25c7ad94347d8eb832e6d4ecbfe0151d', '2222@dd.com', '', '1495444445', '1495444445', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('38', 'test0001', 'test0001', '3596686391f9edec50313d508fb69030', 'test0001@qq.com', '', '1502246717', '1502165289', '1', '1', '0', '1');
INSERT INTO `ob_member` VALUES ('39', 'test0002', 'test0002', '3596686391f9edec50313d508fb69030', 'test0002@qq.com', '', '1502173898', '1502167918', '1', '1', '1', '1');
INSERT INTO `ob_member` VALUES ('40', 'test0003', 'test0003', '3596686391f9edec50313d508fb69030', 'test0003@qq.com', '', '1502173950', '1502173927', '1', '39', '0', '1');
INSERT INTO `ob_member` VALUES ('41', 'test0004', 'test0004', '3596686391f9edec50313d508fb69030', 'test0004@qq.com', '', '1502174081', '1502173989', '1', '40', '1', '1');
INSERT INTO `ob_member` VALUES ('42', 'test0005', 'test0005', '3596686391f9edec50313d508fb69030', 'test0005@qq.com', '', '1502174045', '1502174045', '1', '40', '1', '1');
INSERT INTO `ob_member` VALUES ('43', 'test0006', 'test0006', '3596686391f9edec50313d508fb69030', 'test0006@qq.com', '', '1502246625', '1502246596', '1', '38', '0', '1');
INSERT INTO `ob_member` VALUES ('45', 'sdadsa', 'sdadsa', 'd1cac2f7bae2039b201a5dbe3924bb9d', '', '', '1504934578', '1504934578', '1', '1', '0', '0');
INSERT INTO `ob_member` VALUES ('46', 'sdadsa11', 'sdadsa11', 'd1cac2f7bae2039b201a5dbe3924bb9d', '', '', '1504935264', '1504935264', '1', '1', '0', '0');
INSERT INTO `ob_member` VALUES ('47', 'sdadsa12', 'sdadsa12', 'd1cac2f7bae2039b201a5dbe3924bb9d', '', '', '1504935274', '1504935274', '1', '1', '0', '0');
INSERT INTO `ob_member` VALUES ('48', 'sdadsa13', 'sdadsa13', 'd1cac2f7bae2039b201a5dbe3924bb9d', '', '', '1504935288', '1504935288', '1', '1', '0', '0');
INSERT INTO `ob_member` VALUES ('49', 'sdadsa14', 'sdadsa14', 'd1cac2f7bae2039b201a5dbe3924bb9d', '', '', '1504935301', '1504935301', '1', '1', '0', '0');
INSERT INTO `ob_member` VALUES ('50', 'sdadsa142112', 'sdadsa142112', 'd1cac2f7bae2039b201a5dbe3924bb9d', '', '', '1504935357', '1504935357', '1', '1', '0', '0');
INSERT INTO `ob_member` VALUES ('51', 'sadasdas', 'sadasdas', 'cf8e1b9b2af4974c5136e1f743b505c9', '', '', '1504935617', '1504935617', '1', '1', '0', '0');
INSERT INTO `ob_member` VALUES ('52', '12312', '12312', 'c461ccbe94c0e837e8ca966a121425ae', '', '', '1504938566', '1504938566', '1', '1', '0', '0');
INSERT INTO `ob_member` VALUES ('53', 'sadasdfxx', 'sadasdfxx', '2a7f4cc2adefdbe5e13860118d4627a6', '', '', '1504938594', '1504938594', '1', '1', '0', '0');

-- -----------------------------
-- Table structure for `ob_menu`
-- -----------------------------
DROP TABLE IF EXISTS `ob_menu`;
CREATE TABLE `ob_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `module` char(20) NOT NULL DEFAULT '' COMMENT '模块',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `is_hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `icon` char(30) NOT NULL DEFAULT '' COMMENT '图标',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=utf8 COMMENT='菜单表';

-- -----------------------------
-- Records of `ob_menu`
-- -----------------------------
INSERT INTO `ob_menu` VALUES ('1', '系统首页', '0', '1', 'admin', 'index/index', '0', 'fa-home', '1', '1501928381', '0');
INSERT INTO `ob_menu` VALUES ('16', '会员管理', '0', '3', 'admin', 'member/index', '0', 'fa-users', '1', '1501928389', '0');
INSERT INTO `ob_menu` VALUES ('17', '会员列表', '16', '1', 'admin', 'member/memberlist', '0', 'fa-list', '1', '1495272875', '0');
INSERT INTO `ob_menu` VALUES ('18', '会员添加', '16', '0', 'admin', 'member/memberadd', '0', 'fa-user-plus', '1', '1491837324', '0');
INSERT INTO `ob_menu` VALUES ('27', '权限管理', '16', '0', 'admin', 'auth/grouplist', '0', 'fa-key', '1', '1492000451', '0');
INSERT INTO `ob_menu` VALUES ('32', '权限组编辑', '27', '0', 'admin', 'auth/groupedit', '1', '', '1', '1492002620', '0');
INSERT INTO `ob_menu` VALUES ('34', '授权', '27', '0', 'admin', 'auth_manager/group', '1', '', '1', '0', '0');
INSERT INTO `ob_menu` VALUES ('35', '菜单授权', '27', '0', 'admin', 'auth/menuauth', '1', '', '1', '1492095653', '0');
INSERT INTO `ob_menu` VALUES ('36', '会员授权', '27', '0', 'admin', 'auth_manager/memberaccess', '1', '', '1', '0', '0');
INSERT INTO `ob_menu` VALUES ('68', '系统管理', '0', '4', 'admin', 'config/group', '0', 'fa-wrench', '1', '1501928397', '0');
INSERT INTO `ob_menu` VALUES ('69', '系统设置', '68', '1', 'admin', 'config/setting', '0', 'fa-cogs', '1', '1491748512', '0');
INSERT INTO `ob_menu` VALUES ('70', '配置管理', '68', '4', 'admin', 'config/index', '0', 'fa-cog', '1', '1491668183', '0');
INSERT INTO `ob_menu` VALUES ('71', '配置编辑', '70', '0', 'admin', 'config/configedit', '1', '', '1', '1491674180', '0');
INSERT INTO `ob_menu` VALUES ('72', '配置删除', '70', '0', 'admin', 'config/configDel', '1', '', '1', '1491674201', '0');
INSERT INTO `ob_menu` VALUES ('73', '配置添加', '70', '0', 'admin', 'config/configadd', '0', 'fa-plus', '1', '1491666947', '0');
INSERT INTO `ob_menu` VALUES ('75', '菜单管理', '68', '5', 'admin', 'menu/index', '0', 'fa-th-large', '1', '1491318724', '0');
INSERT INTO `ob_menu` VALUES ('98', '菜单编辑', '75', '0', 'admin', 'menu/menuedit', '1', '', '1', '1491577922', '0');
INSERT INTO `ob_menu` VALUES ('108', '修改密码', '17', '0', 'admin', 'user/update_password', '1', '', '1', '0', '0');
INSERT INTO `ob_menu` VALUES ('109', '修改昵称', '17', '0', 'admin', 'user/update_nickname', '1', '', '1', '1491578211', '0');
INSERT INTO `ob_menu` VALUES ('124', '菜单列表', '75', '0', 'admin', 'menu/menulist', '0', 'fa-list', '1', '1491318271', '0');
INSERT INTO `ob_menu` VALUES ('125', '菜单添加', '75', '0', 'admin', 'menu/menuadd', '0', 'fa-plus', '1', '1491318307', '0');
INSERT INTO `ob_menu` VALUES ('126', '配置列表', '70', '0', 'admin', 'config/configlist', '0', 'fa-list', '1', '1491666890', '1491666890');
INSERT INTO `ob_menu` VALUES ('127', '菜单删除', '75', '0', 'admin', 'menu/menuDel', '1', '', '1', '1491674128', '1491674128');
INSERT INTO `ob_menu` VALUES ('128', '权限组添加', '27', '0', 'admin', 'auth/groupadd', '1', '', '1', '1492002635', '1492002635');
INSERT INTO `ob_menu` VALUES ('131', 'test003', '129', '0', 'admin', 'test/test003', '0', '', '1', '1492010323', '1492010323');
INSERT INTO `ob_menu` VALUES ('132', 'test004', '129', '0', 'admin', 'test/test004', '0', '', '1', '1492010337', '1492010337');
INSERT INTO `ob_menu` VALUES ('133', 'test005', '132', '0', 'admin', 'test/test005', '0', '', '1', '1492320818', '1492010376');
INSERT INTO `ob_menu` VALUES ('134', '授权', '17', '0', 'admin', 'member/memberauth', '1', '', '1', '1492238568', '1492101426');
INSERT INTO `ob_menu` VALUES ('135', '回收站', '68', '0', 'admin', 'trash/trashlist', '0', ' fa-recycle', '1', '1492320214', '1492311462');
INSERT INTO `ob_menu` VALUES ('136', '回收站数据', '135', '0', 'admin', 'trash/trashdatalist', '1', 'fa-database', '1', '1492319477', '1492319392');
INSERT INTO `ob_menu` VALUES ('137', '缓存管理', '68', '0', 'admin', 'cache/index', '0', '', '-1', '1492358787', '1492329681');
INSERT INTO `ob_menu` VALUES ('138', '缓存驱动', '137', '0', 'admin', 'cache/cachelist', '0', '', '-1', '1492358776', '1492329755');
INSERT INTO `ob_menu` VALUES ('139', '缓存数据', '137', '0', 'admin', 'cache/cachedata', '0', '', '-1', '1492341896', '1492329801');
INSERT INTO `ob_menu` VALUES ('140', '服务管理', '68', '0', 'admin', 'service/servicelist', '0', 'fa-server', '1', '1492359063', '1492352972');
INSERT INTO `ob_menu` VALUES ('141', '插件管理', '68', '0', 'admin', 'addon/index', '0', 'fa-puzzle-piece', '1', '1492428072', '1492427605');
INSERT INTO `ob_menu` VALUES ('142', '钩子列表', '141', '0', 'admin', 'addon/hooklist', '0', 'fa-anchor', '1', '1492427665', '1492427665');
INSERT INTO `ob_menu` VALUES ('143', '插件列表', '141', '0', 'admin', 'addon/addonlist', '0', 'fa-list', '1', '1492428116', '1492427838');
INSERT INTO `ob_menu` VALUES ('144', '文章管理', '0', '0', 'admin', 'article/index', '0', 'fa-edit', '1', '1501928404', '1492480187');
INSERT INTO `ob_menu` VALUES ('145', '文章列表', '144', '0', 'admin', 'article/articlelist', '0', 'fa-list', '1', '1492480245', '1492480245');
INSERT INTO `ob_menu` VALUES ('146', '文章分类', '144', '0', 'admin', 'article/articlecategorylist', '0', 'fa-list', '1', '1492480359', '1492480342');
INSERT INTO `ob_menu` VALUES ('147', '文章分类编辑', '146', '0', 'admin', 'article/articlecategoryedit', '1', '', '1', '1492485294', '1492485294');
INSERT INTO `ob_menu` VALUES ('148', '分类添加', '144', '0', 'admin', 'article/articlecategoryadd', '0', 'fa-plus', '1', '1492486590', '1492486576');
INSERT INTO `ob_menu` VALUES ('149', '文章添加', '144', '0', 'admin', 'article/articleadd', '0', 'fa-plus', '1', '1492518453', '1492518453');
INSERT INTO `ob_menu` VALUES ('150', '文章编辑', '145', '0', 'admin', 'article/articleedit', '1', '', '1', '1492879589', '1492879589');
INSERT INTO `ob_menu` VALUES ('151', '插件安装', '143', '0', 'admin', 'addon/addoninstall', '1', '', '1', '1492879763', '1492879763');
INSERT INTO `ob_menu` VALUES ('152', '插件卸载', '143', '0', 'admin', 'addon/addonuninstall', '1', '', '1', '1492879789', '1492879789');
INSERT INTO `ob_menu` VALUES ('153', '文章删除', '145', '0', 'admin', 'article/articledel', '1', '', '1', '1492879960', '1492879960');
INSERT INTO `ob_menu` VALUES ('154', '文章分类删除', '146', '0', 'admin', 'article/articlecategorydel', '1', '', '1', '1492879995', '1492879995');
INSERT INTO `ob_menu` VALUES ('156', '驱动安装', '140', '0', 'admin', 'service/driverinstall', '1', '', '1', '1502267009', '1502267009');
INSERT INTO `ob_menu` VALUES ('157', '接口管理', '0', '0', 'admin', 'api/index', '0', 'fa fa-book', '1', '1504000462', '1504000434');
INSERT INTO `ob_menu` VALUES ('158', '分组管理', '157', '0', 'admin', 'api/apigrouplist', '0', 'fa fa-fw fa-th-list', '1', '1504000977', '1504000723');
INSERT INTO `ob_menu` VALUES ('159', '分组添加', '157', '0', 'admin', 'api/apigroupadd', '0', 'fa fa-fw fa-plus', '1', '1504004646', '1504004646');
INSERT INTO `ob_menu` VALUES ('160', '分组编辑', '157', '0', 'admin', 'api/apigroupedit', '1', '', '1', '1504004710', '1504004710');
INSERT INTO `ob_menu` VALUES ('161', '分组删除', '157', '0', 'admin', 'api/apigroupdel', '1', '', '1', '1504004732', '1504004732');
INSERT INTO `ob_menu` VALUES ('162', '接口列表', '157', '0', 'admin', 'api/apilist', '0', 'fa fa-fw fa-th-list', '1', '1504172326', '1504172326');
INSERT INTO `ob_menu` VALUES ('163', '接口添加', '157', '0', 'admin', 'api/apiadd', '0', 'fa fa-fw fa-plus', '1', '1504172352', '1504172352');
INSERT INTO `ob_menu` VALUES ('164', '接口编辑', '157', '0', 'admin', 'api/apiedit', '1', '', '1', '1504172414', '1504172414');
INSERT INTO `ob_menu` VALUES ('165', '接口删除', '157', '0', 'admin', 'api/apidel', '1', '', '1', '1504172435', '1504172435');
INSERT INTO `ob_menu` VALUES ('166', '优化维护', '0', '0', 'admin', 'maintain/index', '0', 'fa-eye', '1', '1505387650', '1505387256');
INSERT INTO `ob_menu` VALUES ('167', 'SEO管理', '166', '0', 'admin', 'seo/seolist', '0', 'fa-list', '1', '1506309608', '1505387303');
INSERT INTO `ob_menu` VALUES ('168', '数据库', '166', '0', 'admin', 'maintain/database', '0', 'fa-database', '1', '1505539670', '1505539394');
INSERT INTO `ob_menu` VALUES ('169', '数据备份', '168', '0', 'admin', 'database/databackup', '0', 'fa-download', '1', '1506309900', '1505539428');
INSERT INTO `ob_menu` VALUES ('170', '数据还原', '168', '0', 'admin', 'database/datarestore', '0', 'fa-exchange', '1', '1506309911', '1505539492');
INSERT INTO `ob_menu` VALUES ('171', '文件清理', '166', '0', 'admin', 'fileclean/cleanlist', '0', 'fa-file', '1', '1506310152', '1505788517');
INSERT INTO `ob_menu` VALUES ('172', '图片清理', '171', '0', 'admin', 'maintain/pictureclear', '0', 'fa-file-image-o', '-1', '1506310096', '1505789249');
INSERT INTO `ob_menu` VALUES ('173', '文件清理', '171', '0', 'admin', 'maintain/fileclear', '0', 'fa-file', '-1', '1506310100', '1505789307');

-- -----------------------------
-- Table structure for `ob_picture`
-- -----------------------------
DROP TABLE IF EXISTS `ob_picture`;
CREATE TABLE `ob_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '图片名称',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='图片表';

-- -----------------------------
-- Records of `ob_picture`
-- -----------------------------
INSERT INTO `ob_picture` VALUES ('169', 'bdf864d2a1975b26d01ad57e54c9fc90.png', '20170923/bdf864d2a1975b26d01ad57e54c9fc90.png', 'upload/picture/20170923/bdf864d2a1975b26d01ad57e54c9fc90.png', '106149c6f44037465a3f44c212eac5a1ae6cf7da', '1506159017', '1506159017', '1');
INSERT INTO `ob_picture` VALUES ('170', 'c610f674eb34598d3343b5ea427f8ed6.png', '20170923/c610f674eb34598d3343b5ea427f8ed6.png', 'upload/picture/20170923/c610f674eb34598d3343b5ea427f8ed6.png', '8dc6a06544c92b121a591f3202521092a1c911f1', '1506162655', '1506162655', '1');

-- -----------------------------
-- Table structure for `ob_seo`
-- -----------------------------
DROP TABLE IF EXISTS `ob_seo`;
CREATE TABLE `ob_seo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `url` varchar(40) NOT NULL DEFAULT '' COMMENT '模块',
  `seo_title` text NOT NULL COMMENT '标题',
  `seo_keywords` text NOT NULL COMMENT '关键字',
  `seo_description` text NOT NULL COMMENT '描述',
  `usable_val` varchar(255) NOT NULL DEFAULT '' COMMENT '可用变量',
  `sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COMMENT='seo表';

-- -----------------------------
-- Records of `ob_seo`
-- -----------------------------
INSERT INTO `ob_seo` VALUES ('1', '文章详情页', 'home', '文章详情-{$info.title}', '文章详情-关键字', '文章详情-描述', '', '1', '-1', '0', '1505447057');
INSERT INTO `ob_seo` VALUES ('5', '首页', 'home', '首页标题', '首页关键字', '首页描述', '', '2', '-1', '0', '1505447062');
INSERT INTO `ob_seo` VALUES ('40', '首页SEO信息', 'index/index/index', 'OneBase 开发架构{$category_name}{$article_title}', 'OneBase,PHP,{$category_name},{$article_title}', '一款基于ThinkPHP5研发的开源免费基础架构，基于OneBase可以快速的研发各类Web应用。{$article_describe}', '{$category_name}，{$article_title}，{$article_describe}', '0', '1', '1505445912', '1505470293');
INSERT INTO `ob_seo` VALUES ('41', 'OneBase-系统登录', 'index/index/login', 'OneBase', 'OneBase', 'OneBase', '', '0', '1', '1505538002', '1505538026');
INSERT INTO `ob_seo` VALUES ('42', '1122', '333', '344', '5345', '34534', '34534', '0', '-1', '1506309728', '1506309740');
